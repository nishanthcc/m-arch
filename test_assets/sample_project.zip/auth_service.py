import hashlib
import jwt

def authenticate(user, password):
    # Authentication logic
    return jwt.encode({'user': user}, 'secret', algorithm='HS256')
